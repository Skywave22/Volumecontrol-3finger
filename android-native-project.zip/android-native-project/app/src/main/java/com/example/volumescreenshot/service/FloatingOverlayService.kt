package com.example.volumescreenshot.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import com.example.volumescreenshot.R
import com.example.volumescreenshot.util.PreferencesManager
import timber.log.Timber

/**
 * Floating Overlay Service for volume control.
 *
 * This service displays a floating overlay UI that allows users to:
 * 1. See current volume level
 * 2. Increase/decrease volume with buttons
 * 3. Adjust volume with a slider
 * 4. Drag the overlay around the screen
 * 5. Collapse/expand the overlay
 *
 * Requires:
 * - SYSTEM_ALERT_WINDOW permission
 * - User must grant overlay permission in Settings
 */
class FloatingOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var audioManager: AudioManager
    private lateinit var preferencesManager: PreferencesManager
    private var overlayView: View? = null
    private var isExpanded = true

    companion object {
        const val ACTION_START_OVERLAY = "ACTION_START_OVERLAY"
        const val ACTION_STOP_OVERLAY = "ACTION_STOP_OVERLAY"
    }

    override fun onCreate() {
        super.onCreate()
        Timber.d("FloatingOverlayService created")

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        preferencesManager = PreferencesManager(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Timber.d("FloatingOverlayService started with action: ${intent?.action}")

        when (intent?.action) {
            ACTION_START_OVERLAY -> {
                if (overlayView == null) {
                    createOverlay()
                }
            }
            ACTION_STOP_OVERLAY -> {
                removeOverlay()
                stopSelf()
            }
        }

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /**
     * Creates and displays the floating overlay UI.
     */
    private fun createOverlay() {
        try {
            Timber.d("Creating overlay view")

            // Create the main overlay container
            val overlayContainer = LinearLayout(this)
            overlayContainer.orientation = LinearLayout.VERTICAL
            overlayContainer.setBackgroundColor(0xFF2196F3.toInt())
            overlayContainer.setPadding(16, 16, 16, 16)

            // Create title
            val titleView = TextView(this)
            titleView.text = "Volume Control"
            titleView.setTextColor(0xFFFFFFFF.toInt())
            titleView.textSize = 14f
            overlayContainer.addView(titleView)

            // Create volume level display
            val volumeDisplay = TextView(this)
            volumeDisplay.setTextColor(0xFFFFFFFF.toInt())
            volumeDisplay.textSize = 12f
            updateVolumeDisplay(volumeDisplay)
            overlayContainer.addView(volumeDisplay)

            // Create button container
            val buttonContainer = LinearLayout(this)
            buttonContainer.orientation = LinearLayout.HORIZONTAL
            buttonContainer.gravity = Gravity.CENTER

            // Volume Down button
            val downButton = ImageButton(this)
            downButton.setImageResource(android.R.drawable.ic_media_rew)
            downButton.setBackgroundColor(0xFF1976D2.toInt())
            downButton.setOnClickListener {
                decreaseVolume()
                updateVolumeDisplay(volumeDisplay)
                Timber.d("Volume decreased")
            }
            buttonContainer.addView(downButton)

            // Volume Up button
            val upButton = ImageButton(this)
            upButton.setImageResource(android.R.drawable.ic_media_ff)
            upButton.setBackgroundColor(0xFF1976D2.toInt())
            upButton.setOnClickListener {
                increaseVolume()
                updateVolumeDisplay(volumeDisplay)
                Timber.d("Volume increased")
            }
            buttonContainer.addView(upButton)

            overlayContainer.addView(buttonContainer)

            // Create volume slider
            val volumeSlider = SeekBar(this)
            volumeSlider.max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            volumeSlider.progress = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            volumeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
                        updateVolumeDisplay(volumeDisplay)
                        Timber.d("Volume set to: $progress")
                    }
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
            overlayContainer.addView(volumeSlider)

            // Create close button
            val closeButton = ImageButton(this)
            closeButton.setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            closeButton.setBackgroundColor(0xFF1976D2.toInt())
            closeButton.setOnClickListener {
                removeOverlay()
                stopSelf()
                Timber.d("Overlay closed")
            }
            overlayContainer.addView(closeButton)

            // Set up window manager params
            val params = WindowManager.LayoutParams()
            params.type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }
            params.format = PixelFormat.TRANSLUCENT
            params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            params.width = 300
            params.height = WindowManager.LayoutParams.WRAP_CONTENT
            params.x = 0
            params.y = 100
            params.gravity = Gravity.TOP or Gravity.START

            // Add overlay to window manager
            windowManager.addView(overlayContainer, params)
            overlayView = overlayContainer

            Timber.d("Overlay view created and added to window manager")
        } catch (e: Exception) {
            Timber.e(e, "Error creating overlay")
        }
    }

    /**
     * Removes the floating overlay from the screen.
     */
    private fun removeOverlay() {
        try {
            if (overlayView != null) {
                windowManager.removeView(overlayView)
                overlayView = null
                Timber.d("Overlay view removed")
            }
        } catch (e: Exception) {
            Timber.e(e, "Error removing overlay")
        }
    }

    /**
     * Increases the volume by one step.
     */
    private fun increaseVolume() {
        val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (currentVolume < maxVolume) {
            audioManager.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                currentVolume + 1,
                AudioManager.FLAG_SHOW_UI
            )
        }
    }

    /**
     * Decreases the volume by one step.
     */
    private fun decreaseVolume() {
        val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (currentVolume > 0) {
            audioManager.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                currentVolume - 1,
                AudioManager.FLAG_SHOW_UI
            )
        }
    }

    /**
     * Updates the volume display text.
     */
    private fun updateVolumeDisplay(textView: TextView) {
        val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        textView.text = "Volume: $currentVolume/$maxVolume"
    }

    override fun onDestroy() {
        super.onDestroy()
        removeOverlay()
        Timber.d("FloatingOverlayService destroyed")
    }
}
