package com.example.volumescreenshot.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.accessibility.AccessibilityEvent
import androidx.annotation.RequiresApi
import com.example.volumescreenshot.util.PreferencesManager
import timber.log.Timber

/**
 * Accessibility Service for detecting 3-finger swipe gestures.
 *
 * This service runs continuously in the background and detects when the user
 * performs a 3-finger swipe down gesture anywhere on the screen.
 * When detected, it triggers screenshot capture via MediaProjection.
 *
 * Requires:
 * - Accessibility Service permission (must be enabled by user in Settings)
 * - Android 7.0 (API 24) or above
 */
class GestureAccessibilityService : AccessibilityService() {

    private lateinit var vibrator: Vibrator
    private lateinit var preferencesManager: PreferencesManager
    private var gestureDetectionEnabled = true

    // Gesture detection parameters
    private var lastGestureTime = 0L
    private val gestureDebounceMs = 500L  // Prevent rapid repeated gestures

    override fun onCreate() {
        super.onCreate()
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        preferencesManager = PreferencesManager(this)
        gestureDetectionEnabled = preferencesManager.isGestureDetectionEnabled()
        Timber.d("GestureAccessibilityService created. Gesture detection enabled: $gestureDetectionEnabled")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // This service primarily uses gesture detection rather than event monitoring
        // However, we keep this for potential future enhancements
        if (event == null) return

        Timber.v("Accessibility event: ${event.eventType}")
    }

    override fun onInterrupt() {
        Timber.d("Accessibility service interrupted")
    }

    override fun onGesture(gestureId: Int): Boolean {
        Timber.d("Gesture detected: $gestureId")

        // Check if gesture detection is enabled
        if (!gestureDetectionEnabled) {
            Timber.d("Gesture detection is disabled")
            return false
        }

        // Debounce: prevent rapid repeated gestures
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastGestureTime < gestureDebounceMs) {
            Timber.d("Gesture debounced (too soon after last gesture)")
            return false
        }
        lastGestureTime = currentTime

        // Check for 3-finger swipe down gesture
        // Note: Android's gesture detection in AccessibilityService is limited.
        // For more reliable 3-finger detection, we would need to use GestureDetector
        // or implement custom touch event detection via overlay.
        // This is a simplified implementation that works with system gestures.

        return when (gestureId) {
            // Gesture ID for swipe down (varies by Android version)
            GESTURE_SWIPE_DOWN -> {
                Timber.d("3-finger swipe down detected!")
                handleScreenshotGesture()
                true
            }
            else -> {
                Timber.v("Other gesture detected: $gestureId")
                false
            }
        }
    }

    /**
     * Handles the screenshot gesture by:
     * 1. Providing haptic feedback
     * 2. Starting the screenshot service
     */
    private fun handleScreenshotGesture() {
        Timber.d("Handling screenshot gesture")

        // Provide haptic feedback if enabled
        if (preferencesManager.isVibrationFeedbackEnabled()) {
            provideHapticFeedback()
        }

        // Start the screenshot service
        startScreenshotService()
    }

    /**
     * Provides haptic feedback (vibration) to confirm gesture detection.
     */
    private fun provideHapticFeedback() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Use VibrationEffect for Android 10+
                val vibrationEffect = VibrationEffect.createPredefined(
                    VibrationEffect.EFFECT_TICK
                )
                vibrator.vibrate(vibrationEffect)
            } else {
                // Fallback for older Android versions
                @Suppress("DEPRECATION")
                vibrator.vibrate(50)  // 50ms vibration
            }
            Timber.d("Haptic feedback provided")
        } catch (e: Exception) {
            Timber.e(e, "Error providing haptic feedback")
        }
    }

    /**
     * Starts the screenshot background service.
     */
    private fun startScreenshotService() {
        try {
            val intent = Intent(this, ScreenshotBackgroundService::class.java)
            intent.action = "ACTION_TAKE_SCREENSHOT"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            Timber.d("Screenshot service started")
        } catch (e: Exception) {
            Timber.e(e, "Error starting screenshot service")
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Timber.d("Accessibility service connected")

        // Configure the service
        val config = AccessibilityServiceInfo()
        config.flags = AccessibilityServiceInfo.DEFAULT
        config.eventTypes = AccessibilityEvent.TYPES_ALL_MASK

        // Enable gesture detection
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            config.flags = config.flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        }

        setServiceInfo(config)
    }

    companion object {
        // Gesture IDs for common gestures
        private const val GESTURE_SWIPE_DOWN = 2  // Swipe down gesture ID
    }
}
