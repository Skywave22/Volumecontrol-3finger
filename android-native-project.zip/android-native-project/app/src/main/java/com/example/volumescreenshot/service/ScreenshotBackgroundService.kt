package com.example.volumescreenshot.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.volumescreenshot.R
import com.example.volumescreenshot.util.ScreenshotManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import timber.log.Timber

/**
 * Background Foreground Service for screenshot capture using MediaProjection API.
 *
 * This service:
 * 1. Runs in the foreground with a persistent notification
 * 2. Captures screenshots using MediaProjection API
 * 3. Saves screenshots to device gallery/Pictures folder
 * 4. Optimizes battery usage by stopping when not needed
 *
 * Requires:
 * - FOREGROUND_SERVICE permission
 * - FOREGROUND_SERVICE_MEDIA_PROJECTION permission (Android 12+)
 * - CAPTURE_VIDEO_OUTPUT permission
 * - WRITE_EXTERNAL_STORAGE permission
 */
class ScreenshotBackgroundService : Service() {

    private lateinit var mediaProjectionManager: MediaProjectionManager
    private lateinit var screenshotManager: ScreenshotManager
    private val serviceScope = CoroutineScope(Dispatchers.Main)

    companion object {
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "screenshot_service_channel"
        const val ACTION_TAKE_SCREENSHOT = "ACTION_TAKE_SCREENSHOT"
        const val ACTION_STOP_SERVICE = "ACTION_STOP_SERVICE"
    }

    override fun onCreate() {
        super.onCreate()
        Timber.d("ScreenshotBackgroundService created")

        mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenshotManager = ScreenshotManager(this)

        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Timber.d("ScreenshotBackgroundService started with action: ${intent?.action}")

        when (intent?.action) {
            ACTION_TAKE_SCREENSHOT -> {
                startForeground(NOTIFICATION_ID, createNotification())
                takeScreenshot()
            }
            ACTION_STOP_SERVICE -> {
                stopSelf()
            }
        }

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /**
     * Creates a notification channel for Android 8.0+
     */
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Screenshot Service",
                NotificationManager.IMPORTANCE_LOW
            )
            channel.description = "Captures screenshots when gesture is detected"
            channel.setShowBadge(false)

            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
            Timber.d("Notification channel created")
        }
    }

    /**
     * Creates the foreground service notification
     */
    private fun createNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Screenshot Service")
            .setContentText("Ready to capture screenshots")
            .setSmallIcon(R.drawable.ic_volume)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }

    /**
     * Initiates screenshot capture using MediaProjection API
     */
    private fun takeScreenshot() {
        serviceScope.launch {
            try {
                Timber.d("Attempting to capture screenshot")

                // Use ScreenshotManager to handle the actual screenshot capture
                screenshotManager.captureScreenshot { success, message ->
                    if (success) {
                        Timber.d("Screenshot captured and saved: $message")
                        showSuccessNotification(message)
                    } else {
                        Timber.e("Screenshot capture failed: $message")
                        showErrorNotification(message)
                    }

                    // Stop the service after screenshot is taken
                    stopSelf()
                }
            } catch (e: Exception) {
                Timber.e(e, "Error capturing screenshot")
                showErrorNotification("Error: ${e.message}")
                stopSelf()
            }
        }
    }

    /**
     * Shows a success notification
     */
    private fun showSuccessNotification(message: String) {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Screenshot Saved")
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_volume)
            .setAutoCancel(true)
            .build()

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID + 1, notification)
    }

    /**
     * Shows an error notification
     */
    private fun showErrorNotification(message: String) {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Screenshot Failed")
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_volume)
            .setAutoCancel(true)
            .build()

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID + 2, notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        Timber.d("ScreenshotBackgroundService destroyed")
        serviceScope.launch {
            screenshotManager.cleanup()
        }
    }
}
