package com.example.volumescreenshot.service

import android.media.AudioManager
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi
import timber.log.Timber

/**
 * Quick Settings Tile Service for volume control.
 * Provides a Quick Settings tile in the notification shade that allows users to
 * quickly increase/decrease volume or tap to cycle through volume levels.
 *
 * Supported on Android 6.0 (API 24) and above.
 */
@RequiresApi(Build.VERSION_CODES.N)
class VolumeQuickSettingsTile : TileService() {

    private lateinit var audioManager: AudioManager
    private var currentVolumeLevel = 0
    private var maxVolumeLevel = 0

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        maxVolumeLevel = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        updateVolumeLevel()
        Timber.d("VolumeQuickSettingsTile created. Max volume: $maxVolumeLevel")
    }

    override fun onStartListening() {
        super.onStartListening()
        updateVolumeLevel()
        updateTileState()
        Timber.d("VolumeQuickSettingsTile started listening")
    }

    override fun onStopListening() {
        super.onStopListening()
        Timber.d("VolumeQuickSettingsTile stopped listening")
    }

    override fun onClick() {
        super.onClick()
        Timber.d("VolumeQuickSettingsTile clicked. Current volume: $currentVolumeLevel")

        // Cycle through volume levels on each tap
        // Increase volume by 1 step, wrap around at max
        val newVolume = if (currentVolumeLevel >= maxVolumeLevel) {
            0  // Reset to 0 when reaching max
        } else {
            currentVolumeLevel + 1
        }

        // Set the new volume level
        audioManager.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            newVolume,
            AudioManager.FLAG_SHOW_UI  // Show the standard Android volume UI
        )

        // Update the tile state
        updateVolumeLevel()
        updateTileState()

        Timber.d("Volume set to: $currentVolumeLevel/$maxVolumeLevel")
    }

    /**
     * Updates the current volume level from the audio manager.
     */
    private fun updateVolumeLevel() {
        currentVolumeLevel = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
    }

    /**
     * Updates the tile's visual state based on current volume.
     */
    private fun updateTileState() {
        val tile = qsTile ?: return

        // Determine tile state based on volume
        tile.state = if (currentVolumeLevel == 0) {
            Tile.STATE_INACTIVE
        } else {
            Tile.STATE_ACTIVE
        }

        // Update tile label with current volume level
        tile.label = "Volume: $currentVolumeLevel/$maxVolumeLevel"

        // Update tile subtitle (if supported)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.subtitle = "Music Stream"
        }

        // Update tile description (if supported)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            tile.contentDescription = "Volume Control - Current: $currentVolumeLevel"
        }

        // Apply the changes
        tile.updateTile()
    }
}
