package com.example.volumescreenshot.ui

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.volumescreenshot.R
import com.example.volumescreenshot.service.FloatingOverlayService
import com.example.volumescreenshot.util.PermissionManager
import com.example.volumescreenshot.util.PreferencesManager
import com.example.volumescreenshot.viewmodel.MainViewModel
import timber.log.Timber

/**
 * Main Activity for the Volume & Screenshot app.
 *
 * Provides:
 * 1. Permission status display
 * 2. Enable/disable Accessibility Service
 * 3. Enable/disable Overlay UI
 * 4. Settings button
 * 5. Permission request dialogs
 */
class MainActivity : AppCompatActivity() {

    private lateinit var viewModel: MainViewModel
    private lateinit var permissionManager: PermissionManager
    private lateinit var preferencesManager: PreferencesManager
    private lateinit var statusTextView: TextView
    private lateinit var accessibilitySwitch: Switch
    private lateinit var overlaySwitch: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Timber for logging
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }

        Timber.d("MainActivity created")

        // Initialize managers
        permissionManager = PermissionManager(this)
        preferencesManager = PreferencesManager(this)

        // Initialize ViewModel
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)

        // Set up UI
        setupUI()

        // Check permissions on first launch
        if (preferencesManager.isFirstLaunch()) {
            preferencesManager.markFirstLaunchComplete()
            showPermissionDialog()
        }

        // Log permission status
        permissionManager.logPermissionStatus()
    }

    /**
     * Sets up the main UI layout.
     */
    private fun setupUI() {
        val scrollView = ScrollView(this)
        val mainLayout = LinearLayout(this)
        mainLayout.orientation = LinearLayout.VERTICAL
        mainLayout.setPadding(16, 16, 16, 16)

        // Title
        val titleView = TextView(this)
        titleView.text = getString(R.string.welcome_title)
        titleView.textSize = 24f
        titleView.setTextColor(0xFF000000.toInt())
        mainLayout.addView(titleView)

        // Description
        val descriptionView = TextView(this)
        descriptionView.text = getString(R.string.welcome_description)
        descriptionView.textSize = 14f
        descriptionView.setTextColor(0xFF666666.toInt())
        mainLayout.addView(descriptionView)

        // Status
        statusTextView = TextView(this)
        statusTextView.textSize = 12f
        statusTextView.setTextColor(0xFF999999.toInt())
        mainLayout.addView(statusTextView)

        // Accessibility Service Toggle
        val accessibilityLabel = TextView(this)
        accessibilityLabel.text = getString(R.string.settings_accessibility_title)
        accessibilityLabel.textSize = 16f
        mainLayout.addView(accessibilityLabel)

        accessibilitySwitch = Switch(this)
        accessibilitySwitch.isChecked = permissionManager.isAccessibilityServiceEnabled()
        accessibilitySwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                permissionManager.openAccessibilitySettings()
            }
        }
        mainLayout.addView(accessibilitySwitch)

        // Overlay Toggle
        val overlayLabel = TextView(this)
        overlayLabel.text = getString(R.string.settings_overlay_title)
        overlayLabel.textSize = 16f
        mainLayout.addView(overlayLabel)

        overlaySwitch = Switch(this)
        overlaySwitch.isChecked = preferencesManager.isOverlayEnabled()
        overlaySwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (permissionManager.hasOverlayPermission()) {
                    preferencesManager.setOverlayEnabled(true)
                    startOverlayService()
                } else {
                    permissionManager.openOverlaySettings()
                    overlaySwitch.isChecked = false
                }
            } else {
                preferencesManager.setOverlayEnabled(false)
                stopOverlayService()
            }
        }
        mainLayout.addView(overlaySwitch)

        // Settings Button
        val settingsButton = Button(this)
        settingsButton.text = getString(R.string.open_settings)
        settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        mainLayout.addView(settingsButton)

        // Refresh Status Button
        val refreshButton = Button(this)
        refreshButton.text = "Refresh Status"
        refreshButton.setOnClickListener {
            updateStatus()
        }
        mainLayout.addView(refreshButton)

        scrollView.addView(mainLayout)
        setContentView(scrollView)

        // Update status
        updateStatus()
    }

    /**
     * Updates the status display.
     */
    private fun updateStatus() {
        val status = permissionManager.getPermissionStatusMessage()
        statusTextView.text = status
        Timber.d("Status updated: $status")

        // Update switches
        accessibilitySwitch.isChecked = permissionManager.isAccessibilityServiceEnabled()
        overlaySwitch.isChecked = preferencesManager.isOverlayEnabled()
    }

    /**
     * Shows a permission dialog on first launch.
     */
    private fun showPermissionDialog() {
        AlertDialog.Builder(this)
            .setTitle("Permissions Required")
            .setMessage("This app requires several permissions to function properly:\n\n" +
                    "• Accessibility Service - for 3-finger swipe gesture detection\n" +
                    "• Overlay Permission - for floating volume control UI\n" +
                    "• Storage Permission - to save screenshots\n\n" +
                    "Please grant these permissions in Settings.")
            .setPositiveButton("Open Settings") { _, _ ->
                permissionManager.openAccessibilitySettings()
            }
            .setNegativeButton("Later") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    /**
     * Starts the floating overlay service.
     */
    private fun startOverlayService() {
        try {
            val intent = Intent(this, FloatingOverlayService::class.java)
            intent.action = FloatingOverlayService.ACTION_START_OVERLAY

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            Timber.d("Overlay service started")
        } catch (e: Exception) {
            Timber.e(e, "Error starting overlay service")
        }
    }

    /**
     * Stops the floating overlay service.
     */
    private fun stopOverlayService() {
        try {
            val intent = Intent(this, FloatingOverlayService::class.java)
            intent.action = FloatingOverlayService.ACTION_STOP_OVERLAY
            startService(intent)
            Timber.d("Overlay service stopped")
        } catch (e: Exception) {
            Timber.e(e, "Error stopping overlay service")
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    override fun onDestroy() {
        super.onDestroy()
        Timber.d("MainActivity destroyed")
    }
}

// BuildConfig placeholder
object BuildConfig {
    const val DEBUG = true
}
