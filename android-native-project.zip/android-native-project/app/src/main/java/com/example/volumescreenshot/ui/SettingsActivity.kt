package com.example.volumescreenshot.ui

import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.volumescreenshot.R
import com.example.volumescreenshot.util.PreferencesManager
import timber.log.Timber

/**
 * Settings Activity for app configuration.
 *
 * Provides:
 * 1. Gesture sensitivity slider
 * 2. Vibration feedback toggle
 * 3. Gesture detection status
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var preferencesManager: PreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        preferencesManager = PreferencesManager(this)

        setupUI()
        Timber.d("SettingsActivity created")
    }

    /**
     * Sets up the settings UI.
     */
    private fun setupUI() {
        val scrollView = ScrollView(this)
        val mainLayout = LinearLayout(this)
        mainLayout.orientation = LinearLayout.VERTICAL
        mainLayout.setPadding(16, 16, 16, 16)

        // Title
        val titleView = TextView(this)
        titleView.text = getString(R.string.settings_title)
        titleView.textSize = 24f
        titleView.setTextColor(0xFF000000.toInt())
        mainLayout.addView(titleView)

        // Gesture Sensitivity Section
        val sensitivityLabel = TextView(this)
        sensitivityLabel.text = getString(R.string.settings_sensitivity_title)
        sensitivityLabel.textSize = 16f
        sensitivityLabel.setTextColor(0xFF000000.toInt())
        mainLayout.addView(sensitivityLabel)

        val sensitivityDescription = TextView(this)
        sensitivityDescription.text = getString(R.string.settings_sensitivity_description)
        sensitivityDescription.textSize = 12f
        sensitivityDescription.setTextColor(0xFF666666.toInt())
        mainLayout.addView(sensitivityDescription)

        // Sensitivity Slider
        val sensitivitySlider = SeekBar(this)
        sensitivitySlider.max = 100
        sensitivitySlider.progress = preferencesManager.getGestureSensitivity()

        val sensitivityValue = TextView(this)
        sensitivityValue.text = "Sensitivity: ${sensitivitySlider.progress}%"
        sensitivityValue.textSize = 12f
        mainLayout.addView(sensitivityValue)

        sensitivitySlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    preferencesManager.setGestureSensitivity(progress)
                    sensitivityValue.text = "Sensitivity: $progress%"
                    Timber.d("Gesture sensitivity changed to: $progress%")
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        mainLayout.addView(sensitivitySlider)

        // Vibration Feedback Section
        val vibrationLabel = TextView(this)
        vibrationLabel.text = getString(R.string.settings_vibration_title)
        vibrationLabel.textSize = 16f
        vibrationLabel.setTextColor(0xFF000000.toInt())
        mainLayout.addView(vibrationLabel)

        val vibrationDescription = TextView(this)
        vibrationDescription.text = getString(R.string.settings_vibration_description)
        vibrationDescription.textSize = 12f
        vibrationDescription.setTextColor(0xFF666666.toInt())
        mainLayout.addView(vibrationDescription)

        val vibrationSwitch = Switch(this)
        vibrationSwitch.isChecked = preferencesManager.isVibrationFeedbackEnabled()
        vibrationSwitch.setOnCheckedChangeListener { _, isChecked ->
            preferencesManager.setVibrationFeedbackEnabled(isChecked)
            Timber.d("Vibration feedback toggled: $isChecked")
        }
        mainLayout.addView(vibrationSwitch)

        // Gesture Detection Status
        val statusLabel = TextView(this)
        statusLabel.text = "Gesture Detection Status"
        statusLabel.textSize = 16f
        statusLabel.setTextColor(0xFF000000.toInt())
        mainLayout.addView(statusLabel)

        val statusText = TextView(this)
        val isEnabled = preferencesManager.isGestureDetectionEnabled()
        statusText.text = if (isEnabled) {
            "Gesture detection is ENABLED\nThe app will respond to 3-finger swipe gestures"
        } else {
            "Gesture detection is DISABLED\nEnable Accessibility Service to use gestures"
        }
        statusText.textSize = 12f
        statusText.setTextColor(if (isEnabled) 0xFF4CAF50.toInt() else 0xFFFF9800.toInt())
        mainLayout.addView(statusText)

        // About Section
        val aboutLabel = TextView(this)
        aboutLabel.text = "About"
        aboutLabel.textSize = 16f
        aboutLabel.setTextColor(0xFF000000.toInt())
        mainLayout.addView(aboutLabel)

        val aboutText = TextView(this)
        aboutText.text = "Volume & Screenshot Utility v1.0.0\n\n" +
                "Features:\n" +
                "• Quick Settings Volume Tile\n" +
                "• 3-Finger Swipe Screenshot\n" +
                "• Floating Volume Control\n" +
                "• Customizable Settings\n\n" +
                "Requires Android 7.0 (API 24) or above"
        aboutText.textSize = 12f
        aboutText.setTextColor(0xFF666666.toInt())
        mainLayout.addView(aboutText)

        scrollView.addView(mainLayout)
        setContentView(scrollView)
    }

    override fun onDestroy() {
        super.onDestroy()
        Timber.d("SettingsActivity destroyed")
    }
}
