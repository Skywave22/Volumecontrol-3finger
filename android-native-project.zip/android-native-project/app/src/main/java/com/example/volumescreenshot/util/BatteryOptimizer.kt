package com.example.volumescreenshot.util

import android.content.Context
import android.os.BatteryManager
import android.os.Build
import timber.log.Timber

/**
 * Utility for battery optimization and power management.
 *
 * Provides:
 * 1. Battery status monitoring
 * 2. Low battery detection
 * 3. Power optimization strategies
 * 4. Service lifecycle management based on battery state
 */
class BatteryOptimizer(private val context: Context) {

    /**
     * Gets the current battery level (0-100).
     */
    fun getBatteryLevel(): Int {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
        } else {
            val intent = context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
            val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            if (level >= 0 && scale > 0) {
                (level * 100) / scale
            } else {
                -1
            }
        }
    }

    /**
     * Checks if the device is in low battery mode.
     */
    fun isLowBattery(): Boolean {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            batteryManager.isLowBattery
        } else {
            getBatteryLevel() < 15
        }
    }

    /**
     * Checks if the device is currently charging.
     */
    fun isCharging(): Boolean {
        val intent = context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
        val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
        return plugged == BatteryManager.BATTERY_PLUGGED_AC ||
                plugged == BatteryManager.BATTERY_PLUGGED_USB ||
                (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 &&
                        plugged == BatteryManager.BATTERY_PLUGGED_WIRELESS)
    }

    /**
     * Gets battery health status.
     */
    fun getBatteryHealth(): String {
        val intent = context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
        val health = intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1) ?: -1

        return when (health) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Unspecified Failure"
            BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
            else -> "Unknown"
        }
    }

    /**
     * Logs battery status.
     */
    fun logBatteryStatus() {
        Timber.d("=== Battery Status ===")
        Timber.d("Battery Level: ${getBatteryLevel()}%")
        Timber.d("Low Battery: ${isLowBattery()}")
        Timber.d("Charging: ${isCharging()}")
        Timber.d("Health: ${getBatteryHealth()}")
    }

    /**
     * Determines if services should be running based on battery state.
     * Returns false if battery is critically low to save power.
     */
    fun shouldRunServices(): Boolean {
        val batteryLevel = getBatteryLevel()
        val isLowBattery = isLowBattery()

        // Don't run services if battery is below 5%
        if (batteryLevel < 5) {
            Timber.w("Battery critically low ($batteryLevel%), stopping services")
            return false
        }

        // Reduce service frequency if battery is low
        if (isLowBattery) {
            Timber.d("Battery low ($batteryLevel%), reducing service frequency")
        }

        return true
    }

    /**
     * Gets the recommended service update interval based on battery state.
     * Returns interval in milliseconds.
     */
    fun getServiceUpdateInterval(): Long {
        return if (isLowBattery()) {
            5000L  // 5 seconds in low battery mode
        } else if (isCharging()) {
            1000L  // 1 second when charging
        } else {
            2000L  // 2 seconds in normal mode
        }
    }
}
