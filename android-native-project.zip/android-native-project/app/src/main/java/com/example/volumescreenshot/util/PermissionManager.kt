package com.example.volumescreenshot.util

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.AccessibilityManager
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityManager as AccessibilityManagerCompat
import androidx.core.content.ContextCompat
import com.example.volumescreenshot.service.GestureAccessibilityService
import timber.log.Timber

/**
 * Manages runtime permissions and special permissions for the app.
 *
 * Handles:
 * - Accessibility Service permission
 * - Overlay (SYSTEM_ALERT_WINDOW) permission
 * - Storage permissions
 * - Screen capture permission
 */
class PermissionManager(private val context: Context) {

    /**
     * Checks if Accessibility Service is enabled for this app.
     */
    fun isAccessibilityServiceEnabled(): Boolean {
        val accessibilityManager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        val serviceName = "${context.packageName}/${GestureAccessibilityService::class.java.name}"
        return enabledServices.contains(serviceName)
    }

    /**
     * Opens the Accessibility Service settings page.
     */
    fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(intent)
        Timber.d("Opened Accessibility Settings")
    }

    /**
     * Checks if overlay permission is granted.
     */
    fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.SYSTEM_ALERT_WINDOW
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    /**
     * Opens the overlay permission settings page.
     */
    fun openOverlaySettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            android.net.Uri.parse("package:${context.packageName}")
        )
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(intent)
        Timber.d("Opened Overlay Permission Settings")
    }

    /**
     * Checks if storage permission is granted.
     */
    fun hasStoragePermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Android 11+ uses scoped storage
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    /**
     * Checks if screen capture permission is granted.
     * Note: This is typically handled by MediaProjection API.
     */
    fun hasScreenCapturePermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val appOpsManager = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            try {
                appOpsManager.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(),
                    context.packageName
                ) == AppOpsManager.MODE_ALLOWED
            } catch (e: Exception) {
                Timber.e(e, "Error checking screen capture permission")
                false
            }
        } else {
            true  // Older versions don't have this restriction
        }
    }

    /**
     * Checks if vibration permission is granted.
     */
    fun hasVibrationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.VIBRATE
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Gets a list of missing permissions.
     */
    fun getMissingPermissions(): List<String> {
        val missing = mutableListOf<String>()

        if (!isAccessibilityServiceEnabled()) {
            missing.add("Accessibility Service")
        }

        if (!hasOverlayPermission()) {
            missing.add("Overlay Permission")
        }

        if (!hasStoragePermission()) {
            missing.add("Storage Permission")
        }

        if (!hasVibrationPermission()) {
            missing.add("Vibration Permission")
        }

        return missing
    }

    /**
     * Checks if all required permissions are granted.
     */
    fun hasAllPermissions(): Boolean {
        return getMissingPermissions().isEmpty()
    }

    /**
     * Gets a user-friendly permission status message.
     */
    fun getPermissionStatusMessage(): String {
        val missing = getMissingPermissions()
        return if (missing.isEmpty()) {
            "All permissions granted"
        } else {
            "Missing permissions: ${missing.joinToString(", ")}"
        }
    }

    /**
     * Logs current permission status.
     */
    fun logPermissionStatus() {
        Timber.d("=== Permission Status ===")
        Timber.d("Accessibility Service: ${isAccessibilityServiceEnabled()}")
        Timber.d("Overlay Permission: ${hasOverlayPermission()}")
        Timber.d("Storage Permission: ${hasStoragePermission()}")
        Timber.d("Screen Capture Permission: ${hasScreenCapturePermission()}")
        Timber.d("Vibration Permission: ${hasVibrationPermission()}")
        Timber.d("All Permissions: ${hasAllPermissions()}")
    }
}
