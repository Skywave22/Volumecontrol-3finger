package com.example.volumescreenshot.util

import android.content.Context
import android.content.SharedPreferences
import timber.log.Timber

/**
 * Manages app preferences and settings using SharedPreferences.
 *
 * Stores user preferences for:
 * - Accessibility Service enabled/disabled
 * - Overlay UI enabled/disabled
 * - Gesture sensitivity
 * - Vibration feedback enabled/disabled
 */
class PreferencesManager(context: Context) {

    private val sharedPreferences: SharedPreferences = context.getSharedPreferences(
        PREFERENCES_FILE,
        Context.MODE_PRIVATE
    )

    companion object {
        private const val PREFERENCES_FILE = "volume_screenshot_prefs"

        // Preference keys
        private const val KEY_ACCESSIBILITY_ENABLED = "accessibility_enabled"
        private const val KEY_OVERLAY_ENABLED = "overlay_enabled"
        private const val KEY_GESTURE_SENSITIVITY = "gesture_sensitivity"
        private const val KEY_VIBRATION_ENABLED = "vibration_enabled"
        private const val KEY_FIRST_LAUNCH = "first_launch"

        // Default values
        private const val DEFAULT_ACCESSIBILITY_ENABLED = false
        private const val DEFAULT_OVERLAY_ENABLED = false
        private const val DEFAULT_GESTURE_SENSITIVITY = 50  // 0-100
        private const val DEFAULT_VIBRATION_ENABLED = true
    }

    /**
     * Checks if Accessibility Service is enabled.
     */
    fun isAccessibilityServiceEnabled(): Boolean {
        return sharedPreferences.getBoolean(KEY_ACCESSIBILITY_ENABLED, DEFAULT_ACCESSIBILITY_ENABLED)
    }

    /**
     * Sets Accessibility Service enabled/disabled.
     */
    fun setAccessibilityServiceEnabled(enabled: Boolean) {
        sharedPreferences.edit().putBoolean(KEY_ACCESSIBILITY_ENABLED, enabled).apply()
        Timber.d("Accessibility service enabled: $enabled")
    }

    /**
     * Checks if Overlay UI is enabled.
     */
    fun isOverlayEnabled(): Boolean {
        return sharedPreferences.getBoolean(KEY_OVERLAY_ENABLED, DEFAULT_OVERLAY_ENABLED)
    }

    /**
     * Sets Overlay UI enabled/disabled.
     */
    fun setOverlayEnabled(enabled: Boolean) {
        sharedPreferences.edit().putBoolean(KEY_OVERLAY_ENABLED, enabled).apply()
        Timber.d("Overlay enabled: $enabled")
    }

    /**
     * Gets gesture detection sensitivity (0-100).
     */
    fun getGestureSensitivity(): Int {
        return sharedPreferences.getInt(KEY_GESTURE_SENSITIVITY, DEFAULT_GESTURE_SENSITIVITY)
    }

    /**
     * Sets gesture detection sensitivity (0-100).
     */
    fun setGestureSensitivity(sensitivity: Int) {
        val clampedSensitivity = sensitivity.coerceIn(0, 100)
        sharedPreferences.edit().putInt(KEY_GESTURE_SENSITIVITY, clampedSensitivity).apply()
        Timber.d("Gesture sensitivity set to: $clampedSensitivity")
    }

    /**
     * Checks if vibration feedback is enabled.
     */
    fun isVibrationFeedbackEnabled(): Boolean {
        return sharedPreferences.getBoolean(KEY_VIBRATION_ENABLED, DEFAULT_VIBRATION_ENABLED)
    }

    /**
     * Sets vibration feedback enabled/disabled.
     */
    fun setVibrationFeedbackEnabled(enabled: Boolean) {
        sharedPreferences.edit().putBoolean(KEY_VIBRATION_ENABLED, enabled).apply()
        Timber.d("Vibration feedback enabled: $enabled")
    }

    /**
     * Checks if this is the first launch of the app.
     */
    fun isFirstLaunch(): Boolean {
        return sharedPreferences.getBoolean(KEY_FIRST_LAUNCH, true)
    }

    /**
     * Marks the app as launched.
     */
    fun markFirstLaunchComplete() {
        sharedPreferences.edit().putBoolean(KEY_FIRST_LAUNCH, false).apply()
        Timber.d("First launch marked as complete")
    }

    /**
     * Checks if gesture detection is enabled.
     */
    fun isGestureDetectionEnabled(): Boolean {
        return isAccessibilityServiceEnabled()
    }

    /**
     * Resets all preferences to default values.
     */
    fun resetToDefaults() {
        sharedPreferences.edit().clear().apply()
        Timber.d("Preferences reset to defaults")
    }
}
